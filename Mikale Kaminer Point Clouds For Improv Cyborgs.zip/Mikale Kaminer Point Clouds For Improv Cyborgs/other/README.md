# bonk_64bit-version
64bit version of the popular bonk~ object by Miller Puckette for MaxMSP.
Get the binaries from http://vboehm.net/downloads or from the release section.
The original MaxMSP port by Ted Apel, which only runs in 32bit mode, can be found here http://vud.org/max/
